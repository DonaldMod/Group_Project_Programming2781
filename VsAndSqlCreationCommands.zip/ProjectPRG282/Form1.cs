﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPRG282
{
    public partial class Form1 : Form
    {
        Datahandler dh = new Datahandler();
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
            dh.readValues();
            dgvOne.DataSource = dh.bs;
            DbDataRecord dr = dh.bs.Current as DbDataRecord;
            
            foreach (DbDataRecord item in dh.bs)
            {
                ListViewItem row = new ListViewItem(item["StudentNumber"].ToString());
                row.SubItems.Add(item["StudentName"].ToString());
                row.SubItems.Add(item["StudentSurname"].ToString());
                lstVw.Items.Add(row);

            }

        }

        private void dgv_SelectionChanged(object sender, EventArgs e)
        {
            DbDataRecord cat = dh.bs.Current as DbDataRecord;
            if (cat != null)
            {
                txbxNumber.Text = cat["StudentNumber"].ToString();
                txbxNameSurname.Text = cat["StudentName"].ToString();
                txbxPhone.Text = cat["StudentSurname"].ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txbxNumber.Clear();
            txbxNameSurname.Clear();
            txbxPhone.Clear();
        }

        private void lstVw_MouseClick(object sender, MouseEventArgs e)
        {
            txbxNumber.Text = lstVw.SelectedItems[0].SubItems[0].Text;
            txbxNameSurname.Text = lstVw.SelectedItems[0].SubItems[1].Text;
            txbxPhone.Text = lstVw.SelectedItems[0].SubItems[2].Text;

        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
           // dh.InsertData();
        }
    }
}
