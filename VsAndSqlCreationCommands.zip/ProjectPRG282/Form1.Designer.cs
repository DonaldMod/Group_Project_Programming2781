﻿namespace ProjectPRG282
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvOne = new System.Windows.Forms.DataGridView();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.btnUpdateStudents = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnViewCourse = new System.Windows.Forms.Button();
            this.BtnViewStudents = new System.Windows.Forms.Button();
            this.lstVw = new System.Windows.Forms.ListView();
            this.lblStudentNmbr = new System.Windows.Forms.Label();
            this.lblNameAndSurname = new System.Windows.Forms.Label();
            this.lblImage = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblModuleCodes = new System.Windows.Forms.Label();
            this.txbxNameSurname = new System.Windows.Forms.TextBox();
            this.txbxNumber = new System.Windows.Forms.TextBox();
            this.txbxPhone = new System.Windows.Forms.TextBox();
            this.txbxAddress = new System.Windows.Forms.TextBox();
            this.txbxModuleCode = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.clmStudentNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmStudentName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmStudentSurname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.dgvOne)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOne
            // 
            this.dgvOne.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOne.Location = new System.Drawing.Point(139, 12);
            this.dgvOne.Name = "dgvOne";
            this.dgvOne.RowHeadersWidth = 51;
            this.dgvOne.RowTemplate.Height = 24;
            this.dgvOne.Size = new System.Drawing.Size(892, 297);
            this.dgvOne.TabIndex = 0;
            this.dgvOne.SelectionChanged += new System.EventHandler(this.dgv_SelectionChanged);
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.Location = new System.Drawing.Point(12, 158);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(102, 61);
            this.btnAddStudent.TabIndex = 1;
            this.btnAddStudent.Text = "Add new Student";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // btnUpdateStudents
            // 
            this.btnUpdateStudents.Location = new System.Drawing.Point(12, 239);
            this.btnUpdateStudents.Name = "btnUpdateStudents";
            this.btnUpdateStudents.Size = new System.Drawing.Size(102, 56);
            this.btnUpdateStudents.TabIndex = 2;
            this.btnUpdateStudents.Text = "Update Student Details";
            this.btnUpdateStudents.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(12, 399);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(102, 56);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete Student";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(12, 316);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(102, 56);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search a Student";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnViewCourse
            // 
            this.btnViewCourse.Location = new System.Drawing.Point(12, 12);
            this.btnViewCourse.Name = "btnViewCourse";
            this.btnViewCourse.Size = new System.Drawing.Size(102, 56);
            this.btnViewCourse.TabIndex = 5;
            this.btnViewCourse.Text = "View Course Details";
            this.btnViewCourse.UseVisualStyleBackColor = true;
            // 
            // BtnViewStudents
            // 
            this.BtnViewStudents.Location = new System.Drawing.Point(12, 85);
            this.BtnViewStudents.Name = "BtnViewStudents";
            this.BtnViewStudents.Size = new System.Drawing.Size(102, 56);
            this.BtnViewStudents.TabIndex = 6;
            this.BtnViewStudents.Text = "View Student Details";
            this.BtnViewStudents.UseVisualStyleBackColor = true;
            // 
            // lstVw
            // 
            this.lstVw.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmStudentNumber,
            this.clmStudentName,
            this.clmStudentSurname});
            this.lstVw.FullRowSelect = true;
            this.lstVw.HideSelection = false;
            this.lstVw.Location = new System.Drawing.Point(641, 330);
            this.lstVw.Name = "lstVw";
            this.lstVw.Size = new System.Drawing.Size(390, 243);
            this.lstVw.TabIndex = 7;
            this.lstVw.UseCompatibleStateImageBehavior = false;
            this.lstVw.View = System.Windows.Forms.View.Details;
            this.lstVw.SelectedIndexChanged += new System.EventHandler(this.dgv_SelectionChanged);
            this.lstVw.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstVw_MouseClick);
            // 
            // lblStudentNmbr
            // 
            this.lblStudentNmbr.AutoSize = true;
            this.lblStudentNmbr.Location = new System.Drawing.Point(136, 336);
            this.lblStudentNmbr.Name = "lblStudentNmbr";
            this.lblStudentNmbr.Size = new System.Drawing.Size(103, 16);
            this.lblStudentNmbr.TabIndex = 8;
            this.lblStudentNmbr.Text = "Student Number";
            // 
            // lblNameAndSurname
            // 
            this.lblNameAndSurname.AutoSize = true;
            this.lblNameAndSurname.Location = new System.Drawing.Point(136, 367);
            this.lblNameAndSurname.Name = "lblNameAndSurname";
            this.lblNameAndSurname.Size = new System.Drawing.Size(127, 16);
            this.lblNameAndSurname.TabIndex = 9;
            this.lblNameAndSurname.Text = "Name and Surname";
            // 
            // lblImage
            // 
            this.lblImage.AutoSize = true;
            this.lblImage.Location = new System.Drawing.Point(136, 399);
            this.lblImage.Name = "lblImage";
            this.lblImage.Size = new System.Drawing.Size(45, 16);
            this.lblImage.TabIndex = 10;
            this.lblImage.Text = "Image";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(136, 433);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(79, 16);
            this.lblDOB.TabIndex = 11;
            this.lblDOB.Text = "Date of Birth";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(136, 467);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(52, 16);
            this.lblGender.TabIndex = 12;
            this.lblGender.Text = "Gender";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(136, 501);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(46, 16);
            this.lblPhone.TabIndex = 13;
            this.lblPhone.Text = "Phone";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(136, 532);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(58, 16);
            this.lblAddress.TabIndex = 14;
            this.lblAddress.Text = "Address";
            // 
            // lblModuleCodes
            // 
            this.lblModuleCodes.AutoSize = true;
            this.lblModuleCodes.Location = new System.Drawing.Point(136, 565);
            this.lblModuleCodes.Name = "lblModuleCodes";
            this.lblModuleCodes.Size = new System.Drawing.Size(95, 16);
            this.lblModuleCodes.TabIndex = 15;
            this.lblModuleCodes.Text = "Module Codes";
            // 
            // txbxNameSurname
            // 
            this.txbxNameSurname.Location = new System.Drawing.Point(292, 364);
            this.txbxNameSurname.Name = "txbxNameSurname";
            this.txbxNameSurname.Size = new System.Drawing.Size(240, 22);
            this.txbxNameSurname.TabIndex = 16;
            // 
            // txbxNumber
            // 
            this.txbxNumber.Location = new System.Drawing.Point(292, 330);
            this.txbxNumber.Name = "txbxNumber";
            this.txbxNumber.Size = new System.Drawing.Size(240, 22);
            this.txbxNumber.TabIndex = 17;
            // 
            // txbxPhone
            // 
            this.txbxPhone.Location = new System.Drawing.Point(292, 495);
            this.txbxPhone.Name = "txbxPhone";
            this.txbxPhone.Size = new System.Drawing.Size(240, 22);
            this.txbxPhone.TabIndex = 18;
            // 
            // txbxAddress
            // 
            this.txbxAddress.Location = new System.Drawing.Point(292, 526);
            this.txbxAddress.Name = "txbxAddress";
            this.txbxAddress.Size = new System.Drawing.Size(240, 22);
            this.txbxAddress.TabIndex = 19;
            // 
            // txbxModuleCode
            // 
            this.txbxModuleCode.Location = new System.Drawing.Point(292, 559);
            this.txbxModuleCode.Name = "txbxModuleCode";
            this.txbxModuleCode.Size = new System.Drawing.Size(240, 22);
            this.txbxModuleCode.TabIndex = 20;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(292, 433);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(240, 22);
            this.dateTimePicker1.TabIndex = 21;
            this.dateTimePicker1.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // clmStudentNumber
            // 
            this.clmStudentNumber.Text = "Student Number";
            this.clmStudentNumber.Width = 120;
            // 
            // clmStudentName
            // 
            this.clmStudentName.Text = "Student Name";
            this.clmStudentName.Width = 123;
            // 
            // clmStudentSurname
            // 
            this.clmStudentSurname.Text = "Student Surname";
            this.clmStudentSurname.Width = 142;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1068, 630);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txbxModuleCode);
            this.Controls.Add(this.txbxAddress);
            this.Controls.Add(this.txbxPhone);
            this.Controls.Add(this.txbxNumber);
            this.Controls.Add(this.txbxNameSurname);
            this.Controls.Add(this.lblModuleCodes);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.lblImage);
            this.Controls.Add(this.lblNameAndSurname);
            this.Controls.Add(this.lblStudentNmbr);
            this.Controls.Add(this.lstVw);
            this.Controls.Add(this.BtnViewStudents);
            this.Controls.Add(this.btnViewCourse);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdateStudents);
            this.Controls.Add(this.btnAddStudent);
            this.Controls.Add(this.dgvOne);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOne)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOne;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.Button btnUpdateStudents;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnViewCourse;
        private System.Windows.Forms.Button BtnViewStudents;
        private System.Windows.Forms.ListView lstVw;
        private System.Windows.Forms.Label lblStudentNmbr;
        private System.Windows.Forms.Label lblNameAndSurname;
        private System.Windows.Forms.Label lblImage;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblModuleCodes;
        private System.Windows.Forms.TextBox txbxNameSurname;
        private System.Windows.Forms.TextBox txbxNumber;
        private System.Windows.Forms.TextBox txbxPhone;
        private System.Windows.Forms.TextBox txbxAddress;
        private System.Windows.Forms.TextBox txbxModuleCode;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ColumnHeader clmStudentNumber;
        private System.Windows.Forms.ColumnHeader clmStudentName;
        private System.Windows.Forms.ColumnHeader clmStudentSurname;
    }
}

