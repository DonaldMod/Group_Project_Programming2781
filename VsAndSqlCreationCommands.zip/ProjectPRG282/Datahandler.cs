﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ProjectPRG282
{
    internal class Datahandler
    {

       

            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-6H483GT\SQLEXPRESS;Initial Catalog=Project_PRG282;Integrated Security=True");
            string statement;
            SqlCommand cmnd;
            public BindingSource bs = new BindingSource();

            public void readValues()
            {
                SqlDataReader reader;

            try
            {
                conn.Open();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            statement = @"
SELECT  *
FROM Students";
                using (cmnd = new SqlCommand(statement, conn))
                {
                    reader = cmnd.ExecuteReader();
                    bs.DataSource = reader;
                }

                conn.Close();
            }

        /*public void readDatabase()
        {

            try
            {
                conn.Open();
                
            }
            catch (Exception e)
            {

                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            statement = @"
SELECT *
FROM Categories";
            cmnd = new SqlCommand(statement, conn);


            using (SqlDataReader reader = cmnd.ExecuteReader())
            {


                if (reader.HasRows)
                {
                    reader.Open();
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("No rows found in categories table");
                }

            }

            conn.Close();


        }*/

        public void InsertData(string name, string surname, string dob,string gender,string phone, string address,string modulecode)
        {

            try
            {
                conn.Open();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                
            }
            statement = @"
INSERT 
INTO Students(StudentName,StudentSurname,StudentImage,DateOfBirth,Gender,Phone,Address,ModuleCode)
VALUES (${name}, ${surname},${dob},${gender},${phone},${address},${modulecode})  ";

            cmnd = new SqlCommand(statement, conn);
            cmnd.ExecuteNonQuery();

            conn.Close();


        }

        public void UpdataData()
        {

        }

    }
}
