﻿namespace ProjectPRG282
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.btnUpdateStudents = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnViewCourse = new System.Windows.Forms.Button();
            this.BtnViewStudents = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.lblStudentNmbr = new System.Windows.Forms.Label();
            this.lblNameAndSurname = new System.Windows.Forms.Label();
            this.lblImage = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblModuleCodes = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(139, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(892, 297);
            this.dataGridView1.TabIndex = 0;
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.Location = new System.Drawing.Point(39, 158);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(75, 56);
            this.btnAddStudent.TabIndex = 1;
            this.btnAddStudent.Text = "Add new Student";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            // 
            // btnUpdateStudents
            // 
            this.btnUpdateStudents.Location = new System.Drawing.Point(39, 239);
            this.btnUpdateStudents.Name = "btnUpdateStudents";
            this.btnUpdateStudents.Size = new System.Drawing.Size(75, 56);
            this.btnUpdateStudents.TabIndex = 2;
            this.btnUpdateStudents.Text = "Update Student Details";
            this.btnUpdateStudents.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(39, 399);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 56);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete Student";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(39, 316);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 56);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search a Student";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnViewCourse
            // 
            this.btnViewCourse.Location = new System.Drawing.Point(39, 12);
            this.btnViewCourse.Name = "btnViewCourse";
            this.btnViewCourse.Size = new System.Drawing.Size(75, 56);
            this.btnViewCourse.TabIndex = 5;
            this.btnViewCourse.Text = "View Course Details";
            this.btnViewCourse.UseVisualStyleBackColor = true;
            // 
            // BtnViewStudents
            // 
            this.BtnViewStudents.Location = new System.Drawing.Point(39, 85);
            this.BtnViewStudents.Name = "BtnViewStudents";
            this.BtnViewStudents.Size = new System.Drawing.Size(75, 56);
            this.BtnViewStudents.TabIndex = 6;
            this.BtnViewStudents.Text = "View Student Details";
            this.BtnViewStudents.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(641, 336);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(390, 243);
            this.listView1.TabIndex = 7;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // lblStudentNmbr
            // 
            this.lblStudentNmbr.AutoSize = true;
            this.lblStudentNmbr.Location = new System.Drawing.Point(136, 336);
            this.lblStudentNmbr.Name = "lblStudentNmbr";
            this.lblStudentNmbr.Size = new System.Drawing.Size(103, 16);
            this.lblStudentNmbr.TabIndex = 8;
            this.lblStudentNmbr.Text = "Student Number";
            // 
            // lblNameAndSurname
            // 
            this.lblNameAndSurname.AutoSize = true;
            this.lblNameAndSurname.Location = new System.Drawing.Point(136, 367);
            this.lblNameAndSurname.Name = "lblNameAndSurname";
            this.lblNameAndSurname.Size = new System.Drawing.Size(127, 16);
            this.lblNameAndSurname.TabIndex = 9;
            this.lblNameAndSurname.Text = "Name and Surname";
            // 
            // lblImage
            // 
            this.lblImage.AutoSize = true;
            this.lblImage.Location = new System.Drawing.Point(136, 399);
            this.lblImage.Name = "lblImage";
            this.lblImage.Size = new System.Drawing.Size(45, 16);
            this.lblImage.TabIndex = 10;
            this.lblImage.Text = "Image";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(136, 433);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(79, 16);
            this.lblDOB.TabIndex = 11;
            this.lblDOB.Text = "Date of Birth";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(136, 467);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(52, 16);
            this.lblGender.TabIndex = 12;
            this.lblGender.Text = "Gender";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(136, 501);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(46, 16);
            this.lblPhone.TabIndex = 13;
            this.lblPhone.Text = "Phone";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(136, 532);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(58, 16);
            this.lblAddress.TabIndex = 14;
            this.lblAddress.Text = "Address";
            // 
            // lblModuleCodes
            // 
            this.lblModuleCodes.AutoSize = true;
            this.lblModuleCodes.Location = new System.Drawing.Point(136, 565);
            this.lblModuleCodes.Name = "lblModuleCodes";
            this.lblModuleCodes.Size = new System.Drawing.Size(95, 16);
            this.lblModuleCodes.TabIndex = 15;
            this.lblModuleCodes.Text = "Module Codes";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 630);
            this.Controls.Add(this.lblModuleCodes);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.lblImage);
            this.Controls.Add(this.lblNameAndSurname);
            this.Controls.Add(this.lblStudentNmbr);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.BtnViewStudents);
            this.Controls.Add(this.btnViewCourse);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdateStudents);
            this.Controls.Add(this.btnAddStudent);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.Button btnUpdateStudents;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnViewCourse;
        private System.Windows.Forms.Button BtnViewStudents;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label lblStudentNmbr;
        private System.Windows.Forms.Label lblNameAndSurname;
        private System.Windows.Forms.Label lblImage;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblModuleCodes;
    }
}

