﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Group_Project_PRG2782
{
    internal class StudentDataHandler
    {



        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-6H483GT\SQLEXPRESS;Initial Catalog=Northwind;Integrated Security=True");
        string statement;
        SqlCommand cmnd;
        public BindingSource bs = new BindingSource();

        public void readValues()
        {
            SqlDataReader reader;

            try
            {
                conn.Open();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            statement = @"
SELECT  *
FROM Categories";
            using (cmnd = new SqlCommand(statement, conn))
            {
                reader = cmnd.ExecuteReader();
                bs.DataSource = reader;
            }

            conn.Close();
        }

        /*public void readDatabase()
        {

            try
            {
                conn.Open();
                
            }
            catch (Exception e)
            {

                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            statement = @"
SELECT *
FROM Categories";
            cmnd = new SqlCommand(statement, conn);


            using (SqlDataReader reader = cmnd.ExecuteReader())
            {


                if (reader.HasRows)
                {
                    reader.Open();
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("No rows found in categories table");
                }

            }

            conn.Close();


        }*/

        public void InsertData()
        {

            try
            {
                conn.Open();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            statement = @"
INSERT 
INTO Categories(CategoryName,Description)
VALUES ('TestData2', 'TestDataDesc')  ";

            cmnd = new SqlCommand(statement, conn);
            cmnd.ExecuteNonQuery();

            conn.Close();


        }

        public void UpdataData()
        {

        }
    }
}
